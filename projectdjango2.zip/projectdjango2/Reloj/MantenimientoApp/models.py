from django.db import models

# Create your models here.

# Clase base Reloj
class Reloj(models.Model):
    marca = models.CharField(max_length=255)
    _modelo = models.CharField(max_length=255)
    precio = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        abstract = True  # Esto convierte Reloj en una clase abstracta

    def __str__(self):
        return f"Marca: {self.marca}, Modelo: {self.modelo}, Precio: {self.precio}"

# Clase Reloj Cuarzo
class RelojCuarzo(Reloj):
    bateria = models.CharField(max_length=255)

    def __str__(self):
        return f"{super().__str__()}, Tipo: Cuarzo, Bateria: {self.bateria}"

# Clase Reloj Automático
class RelojAutomatico(Reloj):
    reserva_energia = models.IntegerField()

    def __str__(self):
        return f"{super().__str__()}, Tipo: Automático, Reserva de energía: {self.reserva_energia} horas"

# Clase Reloj Manual
class RelojManual(Reloj):
    cuerda_manual = models.BooleanField()

    def __str__(self):
        return f"{super().__str__()}, Tipo: Manual, Cuerda Manual: {self.cuerda_manual}"

# Clase Servicio
class Servicio(models.Model):
    tipo = models.CharField(max_length=255)  # Ejemplo: reparación y mantenimiento
    descripcion = models.TextField()
    precio = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"Servicio: {self.tipo}, Descripción: {self.descripcion}, Precio: ${self.precio}"
    




    from django.db import models  

# Clase base Reloj  
class Reloj(models.Model):  
    marca = models.CharField(max_length=255)  
    _modelo = models.CharField(max_length=255)  
    precio = models.DecimalField(max_digits=10, decimal_places=2)  

    class Meta:  
        abstract = True  

    def realizar_mantenimiento(self):  
        """Método polimórfico para realizar mantenimiento en los relojes."""  
        return "Mantenimiento general realizado."  

# Clase Reloj Cuarzo  
class RelojCuarzo(Reloj):  
    bateria = models.CharField(max_length=255)  

    def realizar_mantenimiento(self):  
        return f"Cambio de batería ({self.bateria}) y limpieza interna realizados para el reloj {self.marca} {self._modelo}."

# Clase Reloj Automático  
class RelojAutomatico(Reloj):  
    reserva_energia = models.IntegerField()  

    def realizar_mantenimiento(self):  
        return f"Limpieza del mecanismo automático y lubricación de piezas realizadas para el reloj {self.marca} {self._modelo}."

# Clase Reloj Manual  
class RelojManual(Reloj):  
    cuerda_manual = models.BooleanField()  

    def realizar_mantenimiento(self):  
        return f"Ajuste del mecanismo de cuerda manual y lubricación realizadas para el reloj {self.marca} {self._modelo}."
